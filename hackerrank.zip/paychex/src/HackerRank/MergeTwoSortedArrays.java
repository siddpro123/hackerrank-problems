package HackerRank;

public class MergeTwoSortedArrays {

	public static void main(String[] args) {
		int[] input = {2,3,10,204,8,1};
		int max_diff = 0;
	    int min_element = input[0];
	        int i;
	        for (i = 1; i < input.length; i++)
	        {
	            if (input[i] - min_element > max_diff)
	                max_diff = input[i] - min_element;
	            if (input[i] < min_element)
	                min_element = input[i];
	        }



//		for ( int i=0; i < input.length; i++)
//		{
//			for ( int j=0+1;j<input.length;j++)
//			{
//				 if (input[j] - input[i] > max_diff)
//				 {
//	                    max_diff = input[j] - input[i];
//				 }
//			}
//		}
		System.out.println(max_diff);
	}
}
